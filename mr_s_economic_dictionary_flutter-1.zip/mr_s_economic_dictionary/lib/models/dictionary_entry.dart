class DictionaryEntry {
  final int id;
  final String englishTerm;
  final String pashtoTerm;
  final String englishDefinition;
  final String pashtoDefinition;
  final String exampleSentence;
  final String category;

  const DictionaryEntry({
    required this.id,
    required this.englishTerm,
    required this.pashtoTerm,
    required this.englishDefinition,
    required this.pashtoDefinition,
    required this.exampleSentence,
    required this.category,
  });

  factory DictionaryEntry.fromMap(Map<String, Object?> map) => DictionaryEntry(
    id: map['id'] as int,
    englishTerm: map['english_term'] as String,
    pashtoTerm: map['pashto_term'] as String,
    englishDefinition: map['english_definition'] as String,
    pashtoDefinition: map['pashto_definition'] as String,
    exampleSentence: (map['example_sentence'] as String?) ?? '',
    category: (map['category'] as String?) ?? 'General Economics',
  );
}
