import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/dictionary_entry.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _db;
  static const _dbName = 'economics.db';
  static const _version = 1;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    final path = p.join(root, _dbName);
    if (!await databaseExists(path)) {
      await _copyBundledDatabase(path);
    }
    _db = await openDatabase(path, readOnly: false, version: _version);
    await _createUserTables(_db!);
    return _db!;
  }

  Future<void> _copyBundledDatabase(String destination) async {
    final data = await rootBundle.load('assets/database/economics.db');
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await FileHelper.writeBytes(destination, bytes);
  }

  Future<void> _createUserTables(Database db) async {
    await db.execute('CREATE TABLE IF NOT EXISTS favorites (entry_id INTEGER PRIMARY KEY)');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS search_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        searched_at TEXT NOT NULL
      )
    ''');
  }

  Future<List<DictionaryEntry>> search(String query, {required bool pashtoFirst}) async {
    final db = await database;
    final q = query.trim();
    if (q.isEmpty) {
      final rows = await db.query('dictionary', orderBy: 'english_term COLLATE NOCASE', limit: 100);
      return rows.map(DictionaryEntry.fromMap).toList();
    }
    final like = '%$q%';
    final rows = await db.rawQuery('''
      SELECT * FROM dictionary
      WHERE english_term LIKE ? COLLATE NOCASE
         OR pashto_term LIKE ?
         OR english_definition LIKE ? COLLATE NOCASE
         OR pashto_definition LIKE ?
      ORDER BY CASE
        WHEN english_term = ? COLLATE NOCASE THEN 0
        WHEN pashto_term = ? THEN 0
        ELSE 1 END,
        english_term COLLATE NOCASE
      LIMIT 100
    ''', [like, like, like, like, q, q]);
    return rows.map(DictionaryEntry.fromMap).toList();
  }

  Future<List<DictionaryEntry>> allEntries() async {
    final db = await database;
    final rows = await db.query('dictionary', orderBy: 'english_term COLLATE NOCASE');
    return rows.map(DictionaryEntry.fromMap).toList();
  }

  Future<bool> isFavorite(int id) async {
    final db = await database;
    return (await db.query('favorites', where: 'entry_id = ?', whereArgs: [id], limit: 1)).isNotEmpty;
  }

  Future<void> toggleFavorite(int id) async {
    final db = await database;
    if (await isFavorite(id)) {
      await db.delete('favorites', where: 'entry_id = ?', whereArgs: [id]);
    } else {
      await db.insert('favorites', {'entry_id': id}, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<List<DictionaryEntry>> favorites() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT d.* FROM dictionary d
      INNER JOIN favorites f ON f.entry_id = d.id
      ORDER BY d.english_term COLLATE NOCASE
    ''');
    return rows.map(DictionaryEntry.fromMap).toList();
  }

  Future<void> addHistory(String query) async {
    if (query.trim().isEmpty) return;
    final db = await database;
    await db.insert('search_history', {
      'query': query.trim(),
      'searched_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<String>> history() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT query FROM search_history
      GROUP BY query COLLATE NOCASE
      ORDER BY MAX(searched_at) DESC LIMIT 20
    ''');
    return rows.map((r) => r['query'] as String).toList();
  }
}

class FileHelper {
  static Future<void> writeBytes(String path, List<int> bytes) async {
    final file = await File(path).create(recursive: true);
    await file.writeAsBytes(bytes, flush: true);
  }
}
