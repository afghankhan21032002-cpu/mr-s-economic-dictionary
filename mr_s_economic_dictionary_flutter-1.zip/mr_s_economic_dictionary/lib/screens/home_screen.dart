import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/dictionary_entry.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  bool _pashtoFirst = false;
  bool _favoritesOnly = false;
  List<DictionaryEntry> _entries = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _controller.addListener(_search);
  }

  @override
  void dispose() {
    _controller.removeListener(_search);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final items = _favoritesOnly
          ? await DatabaseHelper.instance.favorites()
          : await DatabaseHelper.instance.search(_controller.text, pashtoFirst: _pashtoFirst);
      if (!mounted) return;
      setState(() { _entries = items; _loading = false; _error = null; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Could not open the dictionary database. Please reinstall the app.'; });
    }
  }

  Future<void> _search() async {
    if (_favoritesOnly) {
      setState(() => _favoritesOnly = false);
    }
    await DatabaseHelper.instance.addHistory(_controller.text);
    await _load();
  }

  Future<void> _toggleFavorites() async {
    setState(() { _favoritesOnly = !_favoritesOnly; _loading = true; });
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final directionLabel = _pashtoFirst ? 'Pashto → English' : 'English → Pashto';
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mr. S Economic Dictionary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        actions: [
          IconButton(
            tooltip: _favoritesOnly ? 'Show all words' : 'Favorites',
            onPressed: _toggleFavorites,
            icon: Icon(_favoritesOnly ? Icons.menu_book : Icons.star_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
            decoration: const BoxDecoration(
              color: Color(0xFF0D604A),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Economics, made easier.', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('English and Pashto definitions — available offline.', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 18),
              TextField(
                controller: _controller,
                textDirection: _pashtoFirst ? TextDirection.rtl : TextDirection.ltr,
                decoration: InputDecoration(
                  hintText: _pashtoFirst ? 'د اقتصاد کلمه ولټوئ...' : 'Search economics terms...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _controller.text.isEmpty ? null : IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () { _controller.clear(); },
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 8, children: [
                ChoiceChip(
                  label: const Text('English → Pashto'),
                  selected: !_pashtoFirst,
                  onSelected: (_) => setState(() { _pashtoFirst = false; }),
                ),
                ChoiceChip(
                  label: const Text('Pashto → English'),
                  selected: _pashtoFirst,
                  onSelected: (_) => setState(() { _pashtoFirst = true; }),
                ),
              ]),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
            child: Row(children: [
              Expanded(child: Text(_favoritesOnly ? 'Favorite words' : (_controller.text.isEmpty ? 'Browse economics terms' : 'Search results'),
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
              Text('${_entries.length} shown', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            ]),
          ),
          Expanded(child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)))
              : _entries.isEmpty
                ? const Center(child: Text('No matching terms. Try another word.'))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                    itemCount: _entries.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) => _EntryCard(
                      entry: _entries[i],
                      pashtoFirst: _pashtoFirst,
                      onChanged: _load,
                    ),
                  )),
        ]),
      ),
    );
  }
}

class _EntryCard extends StatelessWidget {
  final DictionaryEntry entry;
  final bool pashtoFirst;
  final Future<void> Function() onChanged;
  const _EntryCard({required this.entry, required this.pashtoFirst, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final title = pashtoFirst ? entry.pashtoTerm : entry.englishTerm;
    final subtitle = pashtoFirst ? entry.englishTerm : entry.pashtoTerm;
    return Card(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        title: Text(title, textDirection: pashtoFirst ? TextDirection.rtl : TextDirection.ltr,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(subtitle, textDirection: pashtoFirst ? TextDirection.ltr : TextDirection.rtl,
            style: TextStyle(color: Colors.grey.shade700)),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => EntryDetailScreen(entry: entry, pashtoFirst: pashtoFirst, onChanged: onChanged),
        )),
      ),
    );
  }
}

class EntryDetailScreen extends StatefulWidget {
  final DictionaryEntry entry;
  final bool pashtoFirst;
  final Future<void> Function() onChanged;
  const EntryDetailScreen({super.key, required this.entry, required this.pashtoFirst, required this.onChanged});
  @override
  State<EntryDetailScreen> createState() => _EntryDetailScreenState();
}

class _EntryDetailScreenState extends State<EntryDetailScreen> {
  bool _favorite = false;
  @override
  void initState() {
    super.initState();
    DatabaseHelper.instance.isFavorite(widget.entry.id).then((v) {
      if (mounted) setState(() => _favorite = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Word details'),
        actions: [IconButton(
          tooltip: 'Save favorite',
          onPressed: () async {
            await DatabaseHelper.instance.toggleFavorite(e.id);
            if (!mounted) return;
            setState(() => _favorite = !_favorite);
            await widget.onChanged();
          },
          icon: Icon(_favorite ? Icons.star : Icons.star_border),
        )],
      ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(e.englishTerm, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF0D604A))),
        const SizedBox(height: 8),
        Text(e.pashtoTerm, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        _Section(title: 'Simple English definition', text: e.englishDefinition, direction: TextDirection.ltr),
        const SizedBox(height: 14),
        _Section(title: 'د پښتو تشریح', text: e.pashtoDefinition, direction: TextDirection.rtl),
        const SizedBox(height: 14),
        _Section(title: 'Example sentence', text: e.exampleSentence.isEmpty ? 'No example added yet.' : e.exampleSentence, direction: TextDirection.ltr),
        const SizedBox(height: 14),
        _Section(title: 'Category', text: e.category, direction: TextDirection.ltr),
      ]),
    );
  }
}

class _Section extends StatelessWidget {
  final String title, text;
  final TextDirection direction;
  const _Section({required this.title, required this.text, required this.direction});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0D604A))),
      const SizedBox(height: 8),
      Text(text, textDirection: direction, style: const TextStyle(fontSize: 16, height: 1.5)),
    ]),
  );
}
