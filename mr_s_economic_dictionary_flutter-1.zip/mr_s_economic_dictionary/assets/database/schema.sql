-- Starter schema and data are bundled in assets/database/economics.db.
-- Use this file as a template for adding reviewed entries.
CREATE TABLE IF NOT EXISTS dictionary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  english_term TEXT NOT NULL,
  pashto_term TEXT NOT NULL,
  english_definition TEXT NOT NULL,
  pashto_definition TEXT NOT NULL,
  example_sentence TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'General Economics'
);
