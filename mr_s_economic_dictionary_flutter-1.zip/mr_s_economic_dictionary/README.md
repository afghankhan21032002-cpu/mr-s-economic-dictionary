# Mr. S Economic Dictionary (Flutter starter)

An Android-first offline English ↔ Pashto economics dictionary using Flutter and SQLite.

## What's included
- Flutter app screens: home, search, bilingual word details, favorites.
- Bundled SQLite database at `assets/database/economics.db`.
- Search across English terms, Pashto terms, and definitions.
- Local favorites and search history.
- Pashto right-to-left display support.

## Important dataset note
This starter currently contains **103 seed entries**, not the full requested 1,000. The Pashto translations and definitions are starter content and should be reviewed by a fluent Pashto speaker with economics knowledge before public release. Do not treat this as a fully vetted dictionary. Add the remaining reviewed terms to `assets/database/economics.db` before publishing the 1,000-word edition.

## Requirements
- Flutter SDK (current stable)
- Android Studio / Android SDK
- Internet is needed during development to fetch Flutter packages. The built app's dictionary lookup does not need internet.

## Run
From this directory:

```bash
flutter pub get
flutter doctor
flutter run
```

## Build APK
```bash
flutter build apk --release
```
APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Database structure
`dictionary(id, english_term, pashto_term, english_definition, pashto_definition, example_sentence, category)`

User-specific tables `favorites` and `search_history` are created locally at runtime.

## Add dictionary entries
Open `assets/database/economics.db` with a SQLite editor or add records using a SQLite script. Keep each entry's English term, Pashto term, both definitions, example sentence, and category accurate. If you modify the database schema, update `DatabaseHelper` accordingly.

## Notes
- The package versions in `pubspec.yaml` are reasonable starting versions; run `flutter pub get` and resolve any version constraints against current Flutter package documentation.
- This project has not been compiled in this environment because the Flutter/Android SDK toolchain is not available here.

## Build the APK online (without installing Flutter locally)

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a GitHub repository and upload the extracted project files.
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Choose **Run workflow** (or push to the `main`/`master` branch).
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run, find **Artifacts**, and download `mr-s-economic-dictionary-apk`.
6. Extract the downloaded artifact to get `app-release.apk`, then transfer it to your Android phone and install it. You may need to allow installation from that file source in Android settings.

The APK is only available after the remote build succeeds. This environment does not have Flutter or the Android SDK installed, so it cannot compile the APK directly here.
